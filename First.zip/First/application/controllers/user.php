// controller to show the registration form
<?php 

// create a controller class with extension of CI_Controller
 class user extends CI_Controller{
    public function index()
    {
        $this->load->view('register');
    }
 	// a register function to show the regustration page
 	public function register(){

 	         // to load the register.php 	
 			$this->load->view('register');
 
 			// here the data is stored to database
 			$this->load->model('user_model');
 			//storing the data into the array
 			$formArray =array();
 			$formArray['firstname']= $this->input->post('firstname');
 			$formArray['lastname']= $this->input->post('lastname');
 			$formArray['email']= $this->input->post('email');
 			$formArray['phnumber']= $this->input->post('phnumber');
 			$formArray['country']= $this->input->post('country');
 			$formArray['password']= $this->input->post('password');

            // calling the create function in user_model
 			$check=$this->user_model->create($formArray);
             if($check==true){
                echo '<script>alert("user Added sucessesfully")</script>';
            }
             else{
                echo "error !";
                }
        
 		
 	}
    // to create a view of registration page from the login page
 	public function registerview(){
        $this->load->view('register');
    }
     // to create a view of login page from the registration page
    public function loginview(){
        $this->load->view('login');
    }
    public function login()
    {
        $this->load->model('user_model');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $input = array( 'email'=>$email, 'password'=>$password);

        $data['loggedIn'] = "no";
        $chk = $this->user_model->authenticate($input);
        if($chk)

            $this->load->view('logout');
        else{ 
            echo '<script>alert("Enter the valid email id and password")</script>';
            echo "<p style='color:red; text-align: center; '>Enter the valid email id and password</p>";
            $this->load->view('login');
            }


        //$this->load->view('home/contact');
    }   
public function view()
    {

        $this->load->model('user_Model');
        $data['result']=$this->user_Model->getuser();
        $this->load->view('view', $data);

        }

   public function update($id)
    {
        $this->load->model('user_Model');
        $data['row']=$this->user_Model->get($id);
        $this->load->view('update',$data);
        
    } 
    public function updatedata($id){
        $this->load->model('user_Model');

    $this->user_Model->updatedetails($id);
    $this->load->view('register');
}
public function delete($id)
{
    $this->load->model('user_Model');
    $response=$this->user_Model->deleteuser($id);
    if($response==true){
        echo '<script>alert("user deleted sucessesfully")</script>';
        $this->load->view('register');
    }
    else{
        echo "error !";
    }
}

 }


 ?>