<?php 
class user_model extends CI_Model {


	// this function will save tha data of the user in database, it is pass bt reference
	public function create($formArray){
		//to set the array data
		$this->db->set($formArray);
		// function to insert the data
		$this->db->insert('user',$formArray);
        return true;
	}
	public function authenticate($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM user');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['password']==$check['password'])
            {
                if($input['email']==$check['email'])
                {
                    //session_start();
                    $_SESSION['login'] = "T";
                    $_SESSION['email'] = $input['email'];
                    //is it unsafe to keep password?
                    $_SESSION['password'] = $input['password'];
                    return true;
                    //maybe break here is redundant,but dont want risk
                    break;
                }
            }
        }
        return false;
    }  
    public function getuser(){
    $ret=$this->db->select('*')
                
                  ->get('user');
            return $ret->result();
  }
  public function get($id){
    $ret=$this->db->select('*')->where('id',$id)
                
                  ->get('user');
            return $ret->row();
  }
  public function updatedetails($id){
$data=array(
            
'firstname'=>$this->input->post('firstname'),
'lastname'=>$this->input->post('lastname'),
'email'=>$this->input->post('email'),
'phnumber'=>$this->input->post('phnumber'),
'country'=>$this->input->post('country'),
);
//print_r($data);exit;
$sql_query= $this->db->where('id', $id)
                ->update('user', $data);
           if($sql_query){
             echo '<script>alert("update Sucessesfull")</script>';
        
    }
    else{
       echo '<script>alert("update Failed")</script>';
    }
}

public function deleteuser($id)
    {
        $this->db->where("id", $id);
$this->db->delete("user");
return true;

    }


}


 ?>