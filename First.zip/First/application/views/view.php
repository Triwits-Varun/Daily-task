<html>
   <head>
      <style>
         table, th, td {
            border: 1px solid black;
         }
          button {
    width: 250px;
    margin: 8px;
    padding: 8px;
    background: rgb(0, 102, 128);
    outline: none;
    border: none;
    border-radius: 20px;
    color: white;
    font-size: 17px;
    cursor: pointer;
    transition: 0.5s;
  }
      </style>
   </head>
   <body>
<table id="example3" class="table table-striped table-bordered text-nowrap" >
	<thead>
		<tr>
			<th>ID</th>
			<th>first name</th>
			<th>last name</th>
			<th>email</th>
			<th>mobile number</th>
			<th>country</th>
			<th>password</th>
			<th rowspan="2" colspan="2">Actions</th>
		</tr>
	</thead>
	<tbody>
	<?php
	$cnt=1;
	foreach($result as $row)
	{
	?>
	    <tr>
   			<td><?php echo $cnt;?></td>
   			 <td><?php echo $row->firstname;?></td>
    		<td><?php echo $row->lastname;?></td>
    		<td><?php echo $row->email;?></td>
    		<td><?php echo $row->phnumber;?></td>
    		<td><?php echo $row->country;?></td>
    		<td><?php echo $row->password;?></td>
    		<td><a href="<?php echo site_url('user/update/').$row->id ?>">update</a></td>
    		<td><a href="<?php echo site_url('user/delete/').$row->id ?>">Delete</a></td>
			</td>
		</tr>
	<?php
	$cnt++;
	} ?>
	</tbody>
</table>
<div class=view>
    <form action="<?php echo base_url().'index.php/user/registerview'?>">
    <button ><span >Add User</span></button>
    </form>
    </div>
 </body>