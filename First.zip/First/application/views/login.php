<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login Page</title>
    <style>
		body {
    background: rgba(0, 0, 0, 0.986);
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
  }
  .container {
    width: 400px;
    height: 550px;
    margin: 30px auto;
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
  }
 
  form {
    width: 230px;
    margin: 100px auto;
  }
  form h1 {
    text-align: center;
    font-weight: bolder;
  }

  form label {
    display: block;
    font-size: 16px;
    font-weight: 600;
    padding: 8px;
  }
  input {
    align-items: center;
    width: 100%;
    padding: 8px;
    margin: 8px;
    outline: none;
    border: none;
    border: 1px solid gray;
    border-radius: 5px;
  }
  button {
    width: 250px;
    margin: 8px;
    padding: 8px;
    background: rgb(0, 102, 128);
    outline: none;
    border: none;
    border-radius: 20px;
    color: white;
    font-size: 17px;
    cursor: pointer;
    transition: 0.5s;
  }
  button:hover  {
    background: rgb(52, 197, 233);
    font-size: 18px;
  }
  hr {
    border-top: 2px solid rgb(0, 0, 0);
  }
  .required {
    color: red;
  }
  
 
	</style>
  </head>
  <body>
    <div class="container">
      <form action="<?php echo base_url().'index.php/user/login' ?>" method="post">
        <h1>Login page </h1>
        <hr />
        <label>User Id<span class="required">*</span></label>
        <input type="email" placeholder="Enter the registered email" name="email" id="email"  required/>
        <label>Password<span class="required">*</span></label>
        <input type="password" placeholder="Enter the password" name="password" id="password"  required/>
        
        <button><span>Submit</span></button><br>
        <p><span class="required">*</span>indicates mandatory fields</p>
		<p>Nuw User??<a href="<?php echo base_url().'index.php/user/registerview' ?>" style="color:red; font-size: 20px;">Register</a> </p> 
      </form> 
  </div>  
  </body>
</html>

