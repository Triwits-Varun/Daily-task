<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Registration Page</title>
    <link rel="stylesheet" href="login.css" />
    <style type="text/css">
        body {
    background: rgba(0, 0, 0, 0.986);
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
  }
  .container {
    width: 400px;
    height: 1050px;
    margin: 30px auto;
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
  }
  .view {
     width: 400px;
    height: 150px;
    margin: 30px auto;
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
    

  }
 
  form {
    width: 230px;
    margin: 100px auto;
  }
  form h1 {
    text-align: center;
    font-weight: bolder;
  }

  form label {
    display: block;
    font-size: 16px;
    font-weight: 600;
    padding: 8px;
  }
  input {
    align-items: center;
    width: 100%;
    padding: 8px;
    margin: 8px;
    outline: none;
    border: none;
    border: 1px solid gray;
    border-radius: 5px;
  }
  button {
    width: 250px;
    margin: 8px;
    padding: 8px;
    background: rgb(0, 102, 128);
    outline: none;
    border: none;
    border-radius: 20px;
    color: white;
    font-size: 17px;
    cursor: pointer;
    transition: 0.5s;
  }
  button:hover  {
    background: rgb(52, 197, 233);
    font-size: 18px;
  }
  hr {
    border-top: 2px solid rgb(0, 0, 0);
  }
  .required {
    color: red;
  }
  form check{
    text-align: left;
  }
 
    </style>
  </head>
  <body>
    
    <!-- <a class="nav-sub-link" href="<?php echo base_url().'index.php/user/view'?>">View</a> -->
    <div class="container">
         <form action="<?php echo base_url().'index.php/user/register' ?>" name="registerform" id='registerform' method="post">
          <!-- <form action="<?php echo base_url().'collectData' ?>" name="registerform" id='registerform' method="post"> -->
          <h1>Registration </h1>
          <hr />
          <label>First Name<span class="required">*</span></label>
          <input type="text" placeholder="Enter the first name" name="firstname" id="firstname" onkeypress="return allowOnlyLetters(event,this);"  required/>
          <label>Last Name<span class="required">*</span></label>
          <input type="text" placeholder="Enter the last name" name="lastname" id="lastname" onkeypress="return allowOnlyLetters(event,this);"  required/>
          <label>Email Id<span class="required">*</span></label>
          <input type="email" placeholder="Enter the email id" name="email" id="email"  pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"  required/>
          <label>Phone Number<span class="required">*</span></label>
          <input type="tel" placeholder="Enter the phone number" name="phnumber" id="phnumber" maxlength="10" minlength="10" onkeypress="return onlyNumberKey(event)"  required/>
          
          <label>country<span class="required">*</span></label>
          <input type="text" placeholder="Enter the country" name="country" id="country" onkeypress="return allowOnlyLetters(event,this);"  required/>
          <label>Password<span class="required">*</span></label>
          <input type="password" placeholder="Enter the Password" maxlength="8" id="password" name="password" id="password" required/>
          <label> confirm Password<span class="required">*</span></label>
          <input type="password" placeholder="Enter the Password" maxlength="8" id="confirmPassword"  name="confirmPassword" required/>

          <input type="checkbox"required onclick="return Validate()" class="check"><p>check the box to confirm password</p>
          <button><span>Submit</span></button><br>
          <p><span class="required">*</span>indicates mandatory fields</p>
          <p> Alerady registered??<a href="<?php echo base_url().'index.php/user/loginview' ?>" style="color:red; font-size: 20px;">login</a> </p>  
        </form> 
    </div>
    <div class=view>
       <h1>To view </h1>
    <form action="<?php echo base_url().'index.php/user/view'?>">
    <button ><span >view</span></button>
    </form>
    </div>
    <script>
        //this function will allow only number in the input field
      function onlyNumberKey(evt) {
              
              // Only ASCII character in that range allowed
              var ASCIICode = (evt.which) ? evt.which : evt.keyCode
              if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                  return false;
              return true;
          }
          // this function will allow onlu characters in the input field
      function allowOnlyLetters(e, t)  {    
              if (window.event){    
                var charCode = window.event.keyCode;    
              } else if (e)   
              {    
                var charCode = e.which;    
              }    
              else { return true; }  
              // Only ASCII character in that range allowed  
              if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))    
                return true;    
              else  
              {    
          
                return false;    
              }           
          }   
      // this finction will compare the password and confirmpassword
      //return trye if they match else false
      function Validate( ) {
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirmPassword").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
      }  
    </script>
  </body>
</html>

