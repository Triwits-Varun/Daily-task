
    <?php 

class testmodel extends CI_Model{
    public function create($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('crud',$formArray);
        return true;
    }
    public function getuser(){
    $ret=$this->db->select('*')
                
                  ->get('crud');
            return $ret->result();
  }
   public function deleteuser($id){
        $this->db->where("id", $id);
        $this->db->delete("crud");
        return true;

    }
    public function get($id){
        $ret=$this->db->select('*')->where('id',$id)
                
                  ->get('crud');
            return $ret->row();
    }
     public function updatedetails($id){
         if(!empty($_FILES['picture']['name'])){
            //the path for file uploading is specified
                $config['upload_path'] = 'file/new/';
                //the types that are allowed are specified
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                // the initialization of the upload is done
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    $uploadData = $this->upload->data();
                    // file name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
        $data=array(
            'name'=>$this->input->post('name'),
            'email'=>$this->input->post('email'),
            'phone'=>$this->input->post('phone'),
            'password'=>$this->input->post('password'),
            'file'=> $picture
            );
        //print_r($data);exit;
        $sql_query= $this->db->where('id', $id)
                    ->update('crud', $data);
        if($sql_query){
            return true;
        }else{
            echo '<script>alert("update Failed")</script>';
            }
    }
    
   
    
}
?>