
<?php
class user extends CI_Controller{
public function register(){

            $this->load->model('testmodel');
        if(!empty($_FILES['picture']['name'])){
            //set the path for the image storage
                $config['upload_path'] = 'file/new/';
                // type of files allowed 
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    // file uploading is done by this
                    $uploadData = $this->upload->data();
                    // the filename name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
            
        //storing the data into the array
        $formArray =array();
        $formArray['name']= $this->input->post('name');
        $formArray['email']= $this->input->post('email');
        $formArray['phone']= $this->input->post('phone');
        $formArray['password']= $this->input->post('password');
        $formArray['file']= $picture;

        // calling the create function in user_model
        $check=$this->testmodel->create($formArray);
        if($check==true){
            echo '<script>alert("user Added sucessesfully")</script>';
             $this->load->model('testmodel');
            $data['result']=$this->testmodel->getuser();
            $this->load->view('select_view', $data);
        }else{
            echo "error !";
        }
        
        
    }

     public function delete($id){
        $this->load->model('testmodel');
        $response=$this->testmodel->deleteuser($id);
        if($response==true){
            echo '<script>alert("user deleted sucessesfully")</script>';
            $this->load->model('testmodel');
            $data['result']=$this->testmodel->getuser();
            $this->load->view('select_view', $data);
        }else{
            echo "error !";
        }
    }
     public function updatedata($id){
        $this->load->model('testmodel');
        $response=$this->testmodel->updatedetails($id);
        if($response==true){
            echo '<script>alert("user Updated sucessesfully")</script>';
            $this->load->model('testmodel');
            $data['result']=$this->testmodel->getuser();
            $this->load->view('select_view', $data);
        }else{
            echo "error !";
        }
    }
}
?>