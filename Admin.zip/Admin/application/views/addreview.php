<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
    body{
    background: url("<?php echo base_url('images/back4.jpg'); ?>");
    background-repeat: no-repeat;
    background-size: cover;   
    height: 100%;
}
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=datetime-local], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=file], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}


input[type=submit]:hover {
  background-color: #45a049;
}

/* Style the container/contact section */
.container {
    width:100%;
    margin:8% auto;
    padding:10px;
    border-radius: 20px;
    background-color: rgba(0,0,0,0.23);
	box-shadow: 0 0 17px rgb(25, 24, 24);
    color: aliceblue;
    font-weight: bold;
    font-size: large;
  
}
h1 {
  font-size: 40px;
}

h2 {
  font-size: 30px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}



/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
.main {
height: calc(100vh - 70px);
width: 100%;
overflow-y: scroll;
overflow-x: hidden;
padding: 40px 30px 30px 30px;
}

.main::-webkit-scrollbar-thumb {
background-image:
    linear-gradient(to bottom, rgb(0, 0, 85), rgb(0, 0, 50));
}
.main::-webkit-scrollbar {
width: 5px;
}
.main::-webkit-scrollbar-track {
background-color: #9e9e9eb2;
}

</style>
</head>
<body>
<div class="main">
<div class="container">
  <div style="text-align:center">
    
    <h1>Customer Review Update</h1>
    <p>We Will Make The Celebration Special!!!</p>
    <p>Let's make the event Memorable</p>
  </div>
  <div class="row">
    <div class="column">
      <!-- <img src="image/back2.jpg" height="100%" width="100%"> -->

    </div>
    <div class="column">
      <form action="<?php echo base_url().'index.php/welcome/addreview' ?>"  method="post" enctype="multipart/form-data">
        <label >Name</label>
        <input type="text" id="name" name="name" placeholder="Your name.." onkeypress="return allowOnlyLetters(event,this);" required>
        <label >Select The Event Type</label>
        <select id="event" name="event">
          <option value="India Wedding">India Wedding</option>
          <option value="Western Wedding">Western Wedding</option>
          <option value="Birthday Of A Kid">Birthday Of A Kid</option>
          <option value="Birthday Party">Birthday Party</option>
          <option value="Social Gathering">Social Gathering</option>
          <option value="Public Function">Public Function</option>
          <option value="House Warming">House Warming</option>
          <option value="Cultural Fest">Cultural Fest</option>
        </select>
        <label>Special Note</label>
        <textarea id="note" name="note" placeholder="Write something.." style="height:150px" required></textarea>
        <label >upload images</label>
        <input type="file" id="picture" name="picture"  required>
        <input type="submit">
      

      </form>
    </div>
  </div>
</div>
</div>
<script type="text/javascript">
  let menuicn = document.querySelector(".menuicn");
let nav = document.querySelector(".navcontainer");

menuicn.addEventListener("click",()=>
{
  nav.classList.toggle("navclose");
})
      // this function will allow onlu characters in the input field
      function allowOnlyLetters(e, t)  {    
        if (window.event){    
          var charCode = window.event.keyCode;    
        } else if (e){    
          var charCode = e.which;    
        }else { return true; }  
        // Only ASCII character in that range allowed  
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))    
          return true;    
        else{    
          return false;
        }
      }  
       function onlyNumberKey(evt) {
              
              // Only ASCII character in that range allowed
              var ASCIICode = (evt.which) ? evt.which : evt.keyCode
              if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                  return false;
              return true;
          } 

</script>
</body>
</html>
