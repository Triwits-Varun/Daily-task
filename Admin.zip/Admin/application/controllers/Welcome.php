<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->view('adminlogin');
		

	}
    public function logout()
    {
        $this->load->view('adminlogin');
        

    }
     public function login()
    {
        $this->load->model('reachedus_model');
        $name = $this->input->post('name');
        $password = $this->input->post('password');
        $input = array( 'name'=>$name, 'password'=>$password);

        $data['loggedIn'] = "no";
        $chk = $this->reachedus_model->authenticate($input);
        if($chk){
             $this->load->view('headeradmin');
        $this->load->model('reachedus_model');
         $data['result']=$this->reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);  

        }
        else{ 
            echo '<script>alert("Enter the valid email id and password")</script>';
            echo "<p style='color:red; text-align: center; '>Enter the valid email id and password</p>";
            $this->load->view('adminlogin');
            }
    }   
	public function addview(){
		$this->load->view('headeradmin');
		$this->load->view('addevent');

	}
	public function addevent(){
 
 			// here the data is stored to database
 			$this->load->model('reachedus_model');
 			//storing the data into the array
 			$formArray =array();
 			$formArray['name']= $this->input->post('name');
 			$formArray['email']= $this->input->post('email');
 			$formArray['phnumber']= $this->input->post('phnumber');
 			$formArray['location']= $this->input->post('location');
 			$formArray['date_time']= $this->input->post('date_time');
 			$formArray['event']= $this->input->post('event');
 			$formArray['note']= $this->input->post('note');

            // calling the create function in user_model
 			$check=$this->reachedus_model->addevent($formArray);
             if($check==true){
                echo '<script>alert("Event Added sucessesfully")</script>';
            }
             else{
                echo "error !";
                }
            $this->load->view('headeradmin');
		$this->load->model('reachedus_model');
		 $data['result']=$this->reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);    
        
 		
 	}
 	public function reviewview(){
		$this->load->view('headeradmin');
		$this->load->view('addreview');

	}
	public function addreview(){
    // here the user_model is loaded
        $this->load->model('reachedus_model');
        if(!empty($_FILES['picture']['name'])){
            //set the path for the image storage
                $config['upload_path'] = 'uploads/img/';
                // type of files allowed 
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    // file uploading is done by this
                    $uploadData = $this->upload->data();
                    // the filename name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
            
        //storing the data into the array
 		$formArray =array();
 		$formArray['name']= $this->input->post('name');
 		$formArray['event']= $this->input->post('event');
 		$formArray['note']= $this->input->post('note');
        $formArray['file']= $picture;

        // calling the create function in user_model
 		$check=$this->reachedus_model->addreview($formArray);
        if($check==true){
            echo '<script>alert("review Added sucessesfully")</script>';
        }else{
            echo "error !";
        }
        // once the adding of data is completed the main in views/ is loaded
        $this->load->view('headeradmin');
		$this->load->view('addreview');

    }
    public function addimage(){
		$this->load->view('headeradmin');
		$this->load->view('addimage');

	}
	public function uploadimage(){
    // here the user_model is loaded
        $this->load->model('reachedus_model');
        if(!empty($_FILES['picture']['name'])){
            //set the path for the image storage
                $config['upload_path'] = 'uploads/background/';
                // type of files allowed 
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    // file uploading is done by this
                    $uploadData = $this->upload->data();
                    // the filename name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
            
        //storing the data into the array
 		$formArray =array();
        $formArray['file']= $picture;

        // calling the create function in user_model
 		$check=$this->reachedus_model->uploadimg($formArray);
        if($check==true){
            echo '<script>alert("Image uploaded sucessesfully")</script>';
        }else{
            echo "error !";
        }
        // once the adding of data is completed the main in views/ is loaded
        $this->load->view('headeradmin');
		$this->load->view('addimage');

    }
    public function viewtask(){
        $this->load->view('headeradmin');
        $this->load->model('reachedus_model');
         $data['result']=$this->reachedus_model->gettask();
        $this->load->view('viewtask', $data);

    }
     public function completedevent(){
        $this->load->view('headeradmin');
        $this->load->model('reachedus_model');
         $data['result']=$this->reachedus_model->completedevent();
        $this->load->view('completedevents', $data);

    }
     public function updateeventview($id)
    {
        $this->load->view('headeradmin');
        $this->load->model('reachedus_model');
        $data['row']=$this->reachedus_model->get($id);
        $this->load->view('updateevent',$data);
        
    } 
    public function updateevent($id){
        $this->load->model('reachedus_model');
        $this->reachedus_model->updateevent($id);
        $this->load->view('headeradmin');
        $this->load->model('reachedus_model');
         $data['result']=$this->reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);   
    }
    public function deleteevent($id)
{
    $this->load->model('reachedus_model');
    $response=$this->reachedus_model->deleteevent($id);
    if($response==true){
        echo '<script>alert("Event deleted sucessesfully")</script>';
        $this->load->view('headeradmin');
        $this->load->model('reachedus_model');
         $data['result']=$this->reachedus_model->getreachedus();
        $this->load->view('reached_us', $data); 
    }
    else{
        echo "error !";
    }
}
}
