
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Testimonial</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
</head>
<style>
    .container{

    }
    body{
            margin-top: 00px !important;
        }
        .col-md-12{
            margin-top: 100px;
            margin-bottom: 300px;

        }
        .testimonial{
            border-right: 4px solid #2A3D7D;
            box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.1);
            padding: 30px 30px 30px 130px;
            margin: 0 15px 30px 15px;
            overflow: hidden;
            position: relative;
        }
        .testimonial:before{
            content: "";
            position: absolute;
            bottom: -4px;
            left: -17px;
            border-top: 25px solid #29D18B;
            border-left: 25px solid transparent;
            border-right: 25px solid transparent;
            transform: rotate(45deg);
        }
        .testimonial:after{
            content: "";
            position: absolute;
            top: -4px;
            left: -17px;
            border-top: 25px solid #29D18B;
            border-left: 25px solid transparent;
            border-right: 25px solid transparent;
            transform: rotate(135deg);
        }
        .testimonial .pic{
            display: inline-block;
            width: 100px;
            height: 100px;
            border-radius: 80%;
            overflow: hidden;
            position: absolute;
            top: 30px;
            left: 20px;
        }
        .testimonial .pic img{
            width: 100%;
            height: auto;
        }
        .testimonial .description{
            font-size: 15px;
            letter-spacing: 1px;
            color: #6f6f6f;
            line-height: 25px;
            margin-bottom: 15px;
        }
        .testimonial .title{
            display: inline-block;
            font-size: 20px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #29D18B;
            margin: 0;
        }
        .testimonial .post{
            display: inline-block;
            font-size: 17px;
            color: #29D18B;
            font-style:italic;
        }
        .owl-theme .owl-controls .owl-page span{
            border: 2px solid #2A3D7D;
            background: #fff !important;
          border-radius:0 !important;
            opacity: 1;
        }
        .owl-theme .owl-controls .owl-page.active span,
        .owl-theme .owl-controls .owl-page:hover span{
            background: #29D18B !important;
          border-color:#29D18B;
        }
        @media only screen and (max-width: 767px){
            .testimonial{
                padding: 20px;
                text-align: center;
            }
            .testimonial .pic{
                display: block;
                position: static;
                margin: 0 auto 15px;
            }
        }
</style>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 style="text-align:center;">See What Our Customers Say About Us</h1>
                <div id="testimonial-slider" class="owl-carousel">


                        <?php
                        $cnt=1;
                        foreach($result as $row)
                        {
                        ?>
                   
                   <div class="testimonial">
                    <div class="pic">
                            <img src="<?php echo base_url('uploads/img/' . $row->file); ?>"  alt="Type don't support" >
                        </div>
                        <p class="description">
                            <?php echo $row->note;?>
                        </p>
                    <h3 class="title"><?php echo $row->name;?></h3><br>
                    <small class="post">Event: <?php echo $row->event;?></small>
                    </div>
                 <?php
                 $cnt++;
                } ?>
               
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>

    <script>
        $(document).ready(function(){
            $("#testimonial-slider").owlCarousel({
                items:2,
                itemsDesktop:[1000,2],
                itemsDesktopSmall:[990,2],
                itemsTablet:[768,1],
                pagination:true,
                navigation:false,
                navigationText:["",""],
                slideSpeed:1000,
                autoPlay:true
            });
        });
    </script>
</body>
</html>