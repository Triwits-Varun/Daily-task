<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}


.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

nav{
  position: fixed;
  background: #1b1b1b;
  width: 100%;
  padding: 10px 0;
  z-index: 12;
}
nav .menu{
  max-width: 1250px;
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}
.menu .logo a{
  text-decoration: none;
  color: #fff;
  font-size: 35px;
  font-weight: 600;
}
.menu ul{
  display: inline-flex;
}
.menu ul li{
  list-style: none;
  margin-left: 7px;
}
.menu ul li:first-child{
  margin-left: 0px;
}
.menu ul li a{
  text-decoration: none;
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  padding: 8px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.menu ul li a:hover{
  background: #fff;
  color: black;
}
footer {
  text-align: center;
  padding: 3px;
  background-color: rgb(0, 0, 0);
  color: white;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
.slideshow-container {
  max-width: 500px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 2.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
.column {
    align-items: center;
  float: left;
  width: 50%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
h2{
    text-align: center;
}
</style>
</head>
<body>

<div class="about-section">
  <h4>About Us</h4>
  <h1>About Us</h1>
  <p>We organise the events based on the requirements</p>
  <p>We are in this field since 1999 and we have a good experience in this </p>
  <p>Let's make the time Memorable</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 4</div>
    
      <div class="card">
        <img class="center" src="<?php echo base_url('images/v.jpg'); ?>" alt="Jane" height="200px" width="200px" >
        <div class="container">
          <h2 >Varun Kumar</h2>
          <p class="title" style="  text-align: center;">CEO & Founder</p>
          <p>A creative person .Has 5+ years experience in this field and organised around 500+ events </p>
          <p> <b><span>&#9993;</span></b> varun@gmail.com</p>
          <p> <button class="button"></button></p>
        </div>
      </div>
</div>

<div class="mySlides fade">
  <div class="numbertext" style="color: black;">2 / 4</div>
  <div class="card">
    <img class="center" src="<?php echo base_url('images/r.jpg'); ?>" alt="Jane" height="200px" width="200px" >
    <div class="container">
      <h2>Rakshitha N</h2>
      <p class="title" style="  text-align: center;">Art Director</p>
      <p>Has 5+ years of experience as Art Director and organised around 300+ events</p>
      <p> <b><span>&#9993;</span></b>  rakshitha@gmail.com</p>
      <p><button class="button"></button></p>
    </div>
  </div>
</div>
<div class="mySlides fade">
    <div class="numbertext">3 / 4</div>
    <div class="card">
        <img class="center" src="<?php echo base_url('images/sh.jpg'); ?>" alt="Jane" height="200px" width="200px" >      
        <div class="container">
        <h2>Shashidhar S G</h2>
        <p class="title" style="  text-align: center;">Designer</p>
        <p>Has 5+ years of experience as Designer and organised around 300+ events</p>
        <p> <b><span>&#9993;</span></b> shashi@gmail.com</p>
        <p><button class="button"></button></p>
      </div>
    </div>
  </div>

<div class="mySlides fade">
  <div class="numbertext">4 / 4</div>
  <div class="card">
    <img class="center" src="<?php echo base_url('images/sa.jpg'); ?>" alt="Jane" height="200px" width="200px" >    <div class="container">
      <h2>Sanketh Baglad</h2>
      <p class="title" style="  text-align: center;">Manager</p>
      <p>Has 5+ years of experience as Manager and organised around 300+ events</p>
      <p> <b><span>&#9993;</span> </b>sanketh@gmail.com</p>
      <p><button class="button"></button></p>
    </div>
  </div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
</div>
<script type="text/javascript">
  let slideIndex = 0;
showSlides();
  function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 3000); // Change image every 2 seconds
}
</script>

</body>
</html>
