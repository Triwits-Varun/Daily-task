<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* Style the container/contact section */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}



/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>
<div class="container">
  <div style="text-align:center">
    <h2>Contact Us</h2>
    <h2>Contact Us</h2>
    <h2>Contact Us</h1>
    <p>We respect your effort to contact us thank you!!!!</p>
    <p>Let's make the event Memorable</p>
  </div>
  <div class="row">
    <div class="column">
      <img src="<?php echo base_url('images/contact.jpg'); ?>" height="80%" width="80%">

      <h3><i class="material-icons" style="font-size:36px">pin_drop</i> Reach us</h3>
      <p>Lifeevent Head Office 12th floor,near Brigid ,Banglore Karnataka 566002</p>
        <h3><i class='fa fa-phone'></i> Call us</h3>
        <p>6654718223</p>
        <h3><span>&#9993;</span> Email us</h3>
          <p>lifeenent@gmail.com</p>

    </div>
    <div class="column">
      <form action="<?php echo base_url().'index.php/welcome/contactload' ?>" method="post">
        <label >Name</label>
        <input type="text" id="name" name="name" placeholder="Your name.." onkeypress="return allowOnlyLetters(event,this);" required>
        <label >Email ID</label>
        <input type="email" id="email" name="email" placeholder="Your email.." required>
        <label >Country</label>
        <select id="country" name="country">
          <option value="India">India</option>
          <option value="canada">Canada</option>
          <option value="usa">USA</option>
          <option value="United Arab Emirates">United Arab Emirates</option>
          <option value="United Kingdom">United Kingdom</option>
          <option value="Australia">Australia</option>
          <option value="Uganda">Uganda</option>
          <option value="Thailand">Thailand</option>
        </select>

        <label>Subject</label>
        <textarea id="subject" name="subject" placeholder="Write something.." style="height:150px" required></textarea>
        <input type="submit">
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
      // this function will allow onlu characters in the input field
      function allowOnlyLetters(e, t)  {    
        if (window.event){    
          var charCode = window.event.keyCode;    
        } else if (e){    
          var charCode = e.which;    
        }else { return true; }  
        // Only ASCII character in that range allowed  
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))    
          return true;    
        else{    
          return false;
        }
      }   
</script>
</body>
</html>
