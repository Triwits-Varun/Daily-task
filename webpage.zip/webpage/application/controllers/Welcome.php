<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->view('header');
		$this->load->model('user_model');
		 $data['result']=$this->user_model->getimg();
        $this->load->view('main', $data);
		$this->load->view('footer');
	}
	public function main(){
		$this->load->view('header');
		$this->load->model('user_model');
		 $data['result']=$this->user_model->getimg();
        $this->load->view('main', $data);;
		$this->load->view('footer');
	}
	public function about(){
		$this->load->view('header');
		$this->load->view('about');
		$this->load->view('footer');
	}
	public function contactview(){
		$this->load->view('header');
		$this->load->view('contact');
		$this->load->view('footer');
	}
	
	public function contactload(){

 	         // to load the register.php 	
 
 			// here the data is stored to database
 			$this->load->model('user_model');
 			//storing the data into the array
 			$formArray =array();
 			$formArray['name']= $this->input->post('name');
 			$formArray['email']= $this->input->post('email');
 			$formArray['country']= $this->input->post('country');
 			$formArray['subject']= $this->input->post('subject');

            // calling the create function in user_model
 			$check=$this->user_model->create($formArray);
             if($check==true){
                echo '<script>alert("Message sent")</script>';
            }
             else{
                echo "error !";
                }
            $this->load->view('header');
        	$this->load->model('user_model');
		 $data['result']=$this->user_model->getimg();
        $this->load->view('main', $data);;
        	$this->load->view('footer');
 		
 	}
 	public function review()
    {
    	 $this->load->view('header');
        $this->load->model('user_Model');
        $data['result']=$this->user_Model->getuser();
        $this->load->view('review', $data);
        $this->load->view('footer');
    }
}
