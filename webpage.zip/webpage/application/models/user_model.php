<?php 
class user_model extends CI_Model {


	// this function will save tha data of the user in database, it is pass bt reference
	public function create($formArray){
		//to set the array data
		$this->db->set($formArray);
		// function to insert the data
		$this->db->insert('contact',$formArray);
        return true;
	}
	public function getuser(){
        $ret=$this->db->select('*')
                ->get('review');
            return $ret->result();
    }
    public function getimg(){
        $ret=$this->db->select('*')
                ->get('galary');
            return $ret->result();
    }
}
?>