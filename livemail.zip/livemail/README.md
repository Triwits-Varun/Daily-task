# Sending-HTML-Email-Using-Codeigniter-From-Localhost-and-Live-Server

This project is created by Coderanks.com with the article **Sending HTML Email Using Codeigniter From Localhost and Live Server**

Please check the original [article](https://www.coderanks.com/article/sending-html-email-using-codeigniter-from-localhost-and-live-server) at Coderanks.com 
