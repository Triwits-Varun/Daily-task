-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2023 at 11:57 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(150) NOT NULL,
  `fullname` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phnumber` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `file` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fullname`, `email`, `phnumber`, `password`, `file`) VALUES
(17, 'Varun', 'varunk@gmail.com', '9966332255', '123', 'img1.jpg'),
(22, 'kishor', 'kiranraj@gmail.com', '1597532846', '123', 'img3.jpg'),
(27, 'ramesh', 'zdfsa@dgdfgd.com', '1597532846', '123', 'img71.jpg'),
(28, 'Shashi', 'zdfsa@dgdfgd.com', '1597532846', '123', 'img2.jpg'),
(29, 'quthar', 'qythar@gmail.com', '9988774456', '753', 'img5.jpg'),
(32, 'Abdul Kalam', 'zdfsa@dgdfgd.com', '1597532846', '123', 'Task3.docx'),
(33, 'Rathan Tata', 'rathantata@gmail.com', '1321231231', '123', 'img6.jpg'),
(34, 'Ambani', 'aff@gmail.com', '2222222222', '123', 'img7.jpg'),
(35, 'obama', 'obama@gmail.com', '6633114477', '123', 'coding_standards1.docx');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(150) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
