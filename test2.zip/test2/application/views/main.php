<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Main Page</title>
    <style type="text/css">
      /*for styleing the body*/
        body {
    background: rgba(0, 0, 0, 0.986);
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
  }
  /*for styleing the container class*/
  .container {
    width: 400px;
    height: 450px;
    margin: 30px auto;
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
  }
  /*for styleing the form*/
  form {
    width: 230px;
    margin: 100px auto;
  }
 
  hr {
    border-top: 2px solid rgb(0, 0, 0);
  }
    </style>
  </head>
  <body>
    <div class="container">
        <form action="">
           <h1>Welcome</h1>
            <hr />
        <p style=" font-size: 20px;"><strong>Select the Operation to be performed</strong></p>
        <!-- for the reference to the login page -->
        <p><Strong> Alerady registered?? To login </Strong><br> <a href="<?php echo base_url().'index.php/user/loginview' ?>" style="color:red; font-size: 20px;">login</a> </p>
        <!-- for giving reference to the registration page --> 
          <p><Strong> New user?? To register </Strong><br> <a href="<?php echo base_url().'index.php/user/registerview' ?>"  style="color:red; font-size: 20px;">Register</a> </p>
          <!-- for giving reference to the view for the data -->
          <p><Strong> To view the users??</Strong> <br> <a href="<?php echo base_url().'index.php/user/view' ?>" style="color:red; font-size: 20px;">view</a> </p>
    </form>
    </div> 
  </body>
</html>

