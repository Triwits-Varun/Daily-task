<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Update page</title>
<style>
      body {
    background: rgb(10, 50, 53);
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
  }
  .container {
    width: 400px;
    height: 800px;
    margin: 30px auto;
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
  }
 
  form {
    width: 230px;
    margin: 100px auto;
  }
  form h1 {
    text-align: center;
    font-weight: bolder;
  }

  form label {
    display: block;
    font-size: 16px;
    font-weight: 600;
    padding: 8px;
  }
  input {
    align-items: center;
    width: 100%;
    padding: 8px;
    margin: 8px;
    outline: none;
    border: none;
    border: 1px solid gray;
    border-radius: 5px;
  }
  button {
    width: 250px;
    margin: 8px;
    padding: 8px;
    background: rgb(0, 102, 128);
    outline: none;
    border: none;
    border-radius: 20px;
    color: white;
    font-size: 17px;
    cursor: pointer;
    transition: 0.5s;
  }
  button:hover  {
    background: rgb(52, 197, 233);
    font-size: 18px;
  }
  hr {
    border-top: 2px solid rgb(0, 0, 0);
  }
  .required {
    color: red;
  }
 
 
</style>
  </head>
  <body>
    <div class="container">
      <!-- the  final action of the page is given to the updatedate() in controller/user -->
      <form action="<?php echo site_url('user/updatedata/').$row->id ?>"   method="post" enctype="multipart/form-data">
        <h1>Update your Record </h1>
        <hr />
        <label>full Name<span class="required">*</span></label>
        <input type="text"  name="fullname" id="fullname" onkeypress="return allowOnlyLetters(event,this);" value="<?php echo $row->fullname?>"  required/>
        <label>Email Id<span class="required">*</span></label>
        <input type="email" name="email" id="email"  pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$" value="<?php echo $row->email?>"  required/>
        <label>Phone Number<span class="required">*</span></label>
        <input type="tel" name="phnumber" id="phnumber" maxlength="10" minlength="10" onkeypress="return onlyNumberKey(event)" value="<?php echo $row->phnumber?>"  required/>
        <label>upload the file<span class="required">*</span></label>
        <input type="file" name="picture" id="picture" accept=".jpg, .jpeg, .png, .pdf, .txt, .docx" value="<?php echo $row->file?>"  required/>
        <button><span>Update</span></button><br>
        <p><span class="required">*</span>indicates mandatory fields</p>
      </form> 
  </div>
  <script>
      //this function will allow only number in the input field
    function onlyNumberKey(evt){
      // Only ASCII character in that range allowed
      var ASCIICode = (evt.which) ? evt.which : evt.keyCode
      if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
        return false;
      return true;
    }
    // this function will allow onlu characters in the input field
    function allowOnlyLetters(e, t){    
      if (window.event){
        var charCode = window.event.keyCode;    
      }else if (e){    
        var charCode = e.which;    
      }    
      else { return true; }  
      // Only ASCII character in that range allowed  
     if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))    
      return true;    
      else{    
      return false;    
      }           
    }   
 
  </script>    
  </body>
</html>

