<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Logout page</title>
    <style>
      /*for styleing the body*/
		body {
    background: rgba(0, 0, 0, 0.986);
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
  }
  /*for styleing the container class*/
  .container {
    width: 350px;
    height: 450px;
    margin: 30px auto;
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
  }
  /*for styleing the form and its emements and bouuom*/
 
  form {
    width: 230px;
    margin: 100px auto;
  }
  form h1 {
    text-align: center;
    font-weight: bolder;
  }

  form label {
    display: block;
    font-size: 16px;
    font-weight: 600;
    padding: 8px;
  }
  
  button {
    width: 250px;
    margin: 8px;
    padding: 8px;
    background: rgb(0, 102, 128);
    outline: none;
    border: none;
    border-radius: 20px;
    color: white;
    font-size: 17px;
    cursor: pointer;
    transition: 0.5s;
  }
  button:hover  {
    background: rgb(52, 197, 233);
    font-size: 18px;
  }
  hr {
    border-top: 2px solid rgb(0, 0, 0);
  }
	</style>
  </head>
  <body>
    <div class="container">
      <!-- the final action of the form is passed to the loginview function in the controller/user --> 
      <form action="<?php echo base_url().'index.php/user/loginview' ?>" name="registerform" id='registerform' method="post">
        <h1>Welcome Page </h1>
        <hr />
        <label>congratulations U have loged in Sucessfully thank you!!!</label>
        <button><span>Logout</span></button><br>
      </form> 
  </div>  
  </body>
</html>

