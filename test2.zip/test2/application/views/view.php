<!DOCTYPE html>
<html lang="en">
<head>
    <title>View page</title>
    <style>
        /*for giving the border to to table*/
        body {
    background: lightblue;
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
  }
         table, th, td {
            align-content: center;
            border: 1px solid black;
         }
          button {
    width: 250px;
    margin: 8px;
    padding: 8px;
    background: rgb(0, 102, 128);
    outline: none;
    border: none;
    border-radius: 20px;
    color: white;
    font-size: 17px;
    cursor: pointer;
    transition: 0.5s;
  }
  button:hover  {
    background: rgb(52, 197, 233);
    font-size: 18px;
  }
      </style>
</head>
<body>
    <!-- the table and its headers and created -->
    <table  >
    <thead>
        <tr>
            <th>ID</th>
            <th>fullname</th>
            <th>email</th>
            <th>mobile number</th>
            <th>password</th>
            <th>file</th>
            <th>view file</th>
            <th rowspan="2" colspan="2">Actions</th>
        </tr>
    </thead>
    <tbody>
        <!-- the data is fetched from the database and will be displayed in the respective cells in the table created along the the actions like update and delete -->
    <?php
    $cnt=1;
    foreach($result as $row)
    {
    ?>
        <tr>
            <td><?php echo $cnt;?></td>
             <td><?php echo $row->fullname;?></td>
            <td><?php echo $row->email;?></td>
            <td><?php echo $row->phnumber;?></td>
            <td><?php echo $row->password;?></td>
            <!-- to display the uploaded files in the view table -->
            <td><img src="<?php echo base_url('uploads/images/' . $row->file); ?>" alt="Type don't support" width="150" height="100" ></td>
            <!-- it gives the view option by which the images can be viewed and other files can be downloaded -->
           <td> <a href="<?php echo base_url('uploads/images/' . $row->file); ?>" >view</a></td>
            <!-- using site_url we are calling update() in controller/user  -->
            <td><a href="<?php echo site_url('user/update/').$row->id ?>">update</a></td>
            <!-- using the site_url we are calling the delete() in controller/user -->
            <td><a href="<?php echo site_url('user/delete/').$row->id ?>">Delete</a></td>
            </td>
        </tr>
    <?php
    $cnt++;
    } ?>
    </tbody>
</table>
<div class=view>
    <!-- the final action of this for is given to the reisterview() in the controller/user -->
    <form action="<?php echo base_url().'index.php/user/registerview'?>">
    <button ><span >Add User</span></button>
    </form>
    </div>
    
</body>
</html>