<?php 
class user_model extends CI_Model {


	// this function will save tha data of the user in database, it is pass bt reference
	public function create($formArray){
		//to set the array data
		$this->db->set($formArray);
		// function to insert the data
		$this->db->insert('register',$formArray);
        return true;
	}
    // this function will get all the data in the register table and will return the result to 
	public function getuser(){
        $ret=$this->db->select('*')
                ->get('register');
            return $ret->result();
    }
    //this finction will get the data of a perticular id passed from the database
    public function get($id){
        $ret=$this->db->select('*')->where('id',$id)
                
                  ->get('register');
            return $ret->row();
    }
    // this function will update the details of the perticular recode in the database based on the id passed 
    public function updatedetails($id){
         if(!empty($_FILES['picture']['name'])){
            //the path for file uploading is specified
                $config['upload_path'] = 'uploads/images/';
                //the types that are allowed are specified
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                // the initialization of the upload is done
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    $uploadData = $this->upload->data();
                    // file name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
        $data=array(
            'fullname'=>$this->input->post('fullname'),
            'email'=>$this->input->post('email'),
            'phnumber'=>$this->input->post('phnumber'),
            'file'=> $picture
            );
        //print_r($data);exit;
        $sql_query= $this->db->where('id', $id)
                    ->update('register', $data);
        if($sql_query){
            echo '<script>alert("update Sucessesfull")</script>';
        }else{
            echo '<script>alert("update Failed")</script>';
            }
    }
    // this function will delete the perticular record in the database based in the id passed
    public function deleteuser($id){
        $this->db->where("id", $id);
        $this->db->delete("register");
        return true;

    }
    //this function will authenticate the data recived and the data in the database

    public function authenticate($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM register');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['password']==$check['password'])
            {
                if($input['email']==$check['email'])
                {
                    //session_start();
                    $_SESSION['login'] = "T";
                    $_SESSION['email'] = $input['email'];
                    //is it unsafe to keep password?
                    $_SESSION['password'] = $input['password'];
                    return true;
                    //maybe break here is redundant,but dont want risk
                    break;
                }
            }
        }
        return false;
    } 
    
}
?>