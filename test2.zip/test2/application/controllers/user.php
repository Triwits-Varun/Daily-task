<?php 

// create a controller class with extension of CI_Controller
class user extends CI_Controller{
    public function index()
    {
        $this->load->view('main');
    }
 	// a register function to show the regustration page
 	public function register(){
    // here the user_model is loaded
        $this->load->model('user_model');
        if(!empty($_FILES['picture']['name'])){
            //set the path for the image storage
                $config['upload_path'] = 'uploads/images/';
                // type of files allowed 
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    // file uploading is done by this
                    $uploadData = $this->upload->data();
                    // the filename name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
            
        //storing the data into the array
 		$formArray =array();
 		$formArray['fullname']= $this->input->post('fullname');
 		$formArray['email']= $this->input->post('email');
 		$formArray['phnumber']= $this->input->post('phnumber');
 		$formArray['password']= $this->input->post('password');
        $formArray['file']= $picture;

        // calling the create function in user_model
 		$check=$this->user_model->create($formArray);
        if($check==true){
            echo '<script>alert("user Added sucessesfully")</script>';
        }else{
            echo "error !";
        }
        // once the adding of data is completed the main in views/ is loaded
        $this->load->view('main');
    }
    //this function is used to load the registrater.php that is present in views/
    public function registerview(){
        $this->load->view('register');
    }
    //this function is usedto load the main.php present in views/
    public function back(){
        $this->load->view('main');
    }
    // this function is used to load the login.php present in views/
    public function loginview(){
        $this->load->view('login');
    }
    //this function is used for the userid and password validation in the loginpage 
     public function login()
    {
        $this->load->model('user_model');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $input = array( 'email'=>$email, 'password'=>$password);

        $data['loggedIn'] = "no";
        $chk = $this->user_model->authenticate($input);
        if($chk){
            //this is used to load the logout.php presten in views/
            $this->load->view('logout');
        }else{ 
            echo '<script>alert("Enter the valid email id and password")</script>';
            echo "<p style='color:red; text-align: center; '>Enter the valid email id and password</p>";
            // this is used to load the login.php present in the view/ when the password did not match
            $this->load->view('login');
        }
    }   
    // this function used to fetch the data and display in th table present in view.php in views/
    public function view()
    {
        $this->load->model('user_Model');
        $data['result']=$this->user_Model->getuser();
        $this->load->view('view', $data);
    }
    // this function is load update.php presint in views/ and lode the respective data to update.php
    public function update($id)
    {
        $this->load->model('user_Model');
        $data['row']=$this->user_Model->get($id);
        $this->load->view('update',$data);
        
    } 
    //once the data is updated this function will update the data in the data base 
    public function updatedata($id){
        $this->load->model('user_Model');
        $this->user_Model->updatedetails($id);
        $this->load->view('main');
    }
    // this function is used to delete the perticular record from the database based on the id pased 
    public function delete($id){
        $this->load->model('user_Model');
        $response=$this->user_Model->deleteuser($id);
        if($response==true){
            echo '<script>alert("user deleted sucessesfully")</script>';
            $this->load->view('main');
        }else{
            echo "error !";
        }
    }
}
?>